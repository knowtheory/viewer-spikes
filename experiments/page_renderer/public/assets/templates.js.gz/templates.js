(function(){
window.JST = window.JST || {};

window.JST['viewer'] = DC._.template('<div class="viewer">\n  <div class="pages"></div>\n  <div class="footer"></div>\n</div>\n');
})();